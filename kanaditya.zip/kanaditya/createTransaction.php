<?php
$apiKey = 'AZukf1a8ZSGA85lhrez6jkUT212fT32cA4Gwcb9U';
$privateKey = 'mqMOV-FL8k2-NH2SA-iSmBQ-WJZTB';
$merchantCode = 'T40114';

$data = [
    'method' => $_POST['payment_method'], // example: QRIS
    'merchant_ref' => 'INV' . time(),
    'amount' => $_POST['amount'],
    'customer_name' => $_POST['first_name'] . ' ' . $_POST['last_name'],
    'customer_email' => $_POST['email'],
    'customer_phone' => $_POST['phone'],
    'order_items' => [
        [
            'sku' => 'DONATION',
            'name' => 'Donation',
            'price' => $_POST['amount'],
            'quantity' => 1
        ]
    ],
    'return_url' => 'https://kanaditya.com/thankyou',
    'expired_time' => (time() + (24 * 60 * 60)), // 24 hours
    'signature' => hash_hmac('sha256', $merchantCode . time() . $_POST['amount'], $privateKey)
];

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_FRESH_CONNECT => true,
    CURLOPT_URL => "https://tripay.co.id/api/transaction/create",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query($data),
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $apiKey]
]);

$response = curl_exec($curl);
curl_close($curl);

echo $response;
?>
